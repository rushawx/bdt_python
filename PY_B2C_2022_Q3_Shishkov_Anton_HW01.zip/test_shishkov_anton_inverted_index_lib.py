"""tests for inverted index module"""
from textwrap import dedent

import pytest

from task_shishkov_anton_inverted_index_lib import InvertedIndex
from task_shishkov_anton_inverted_index_lib import load_documents, build_inverted_index

DATASET_BIG_PATH = 'wikipedia_sample.txt'
DATASET_TINY_PATH = 'tiny_wikipedia_sample.txt'

DATASET_TINY_STR = '''\
123\tsome words A_word and nothing
2\tsome word B_word in this dataset
5\tfamous_phrases to be or not to be
37\tall words such as A_word and B_word are here
'''


def test_can_load_documents_v1():
    """Tests document loading"""
    loaded_documents = load_documents(DATASET_TINY_PATH)
    expected_documents = {
        123: 'some words a_word and nothing',
        2: 'some word b_word in this dataset',
        5: 'famous_phrases to be or not to be',
        37: 'all words such as a_word and b_word are here'
    }
    assert expected_documents == loaded_documents, (
        'load_documents incorrectly loaded dataset'
    )


def test_can_load_documents_v2(tmpdir):
    """Tests document loading"""
    dataset_str = dedent('''\
        123\tsome words A_word and nothing
        2\tsome word B_word in this dataset
        5\tfamous_phrases to be or not to be
        37\tall words such as A_word and B_word are here
    ''')
    dataset_fio = tmpdir.join('tiny_dataset.txt')
    dataset_fio.write(dataset_str)
    loaded_documents = load_documents(dataset_fio)
    expected_documents = {
        123: 'some words a_word and nothing',
        2: 'some word b_word in this dataset',
        5: 'famous_phrases to be or not to be',
        37: 'all words such as a_word and b_word are here'
    }
    assert expected_documents == loaded_documents, (
        'load_documents incorrectly loaded dataset'
    )


@pytest.fixture()
def tiny_dataset_fio(tmpdir):
    """Creates tiny dataset FIO"""
    dataset_fio = tmpdir.join('dataset.txt')
    dataset_fio.write(DATASET_TINY_STR)
    return dataset_fio


def test_can_load_documents_v3(tiny_dataset_fio):
    """Tests document loading"""
    loaded_documents = load_documents(tiny_dataset_fio)
    expected_documents = {
        123: 'some words a_word and nothing',
        2: 'some word b_word in this dataset',
        5: 'famous_phrases to be or not to be',
        37: 'all words such as a_word and b_word are here'
    }
    assert expected_documents == loaded_documents, (
        'load_documents incorrectly loaded dataset'
    )


@pytest.mark.parametrize(
    'query, expected_answer',
    [
        pytest.param(['A_word'], [123, 37], id='A_word'),
        pytest.param(['B_word'], [2, 37], id='B_word'),
        pytest.param(['A_word', 'B_word'], [37], id='both words'),
        pytest.param(['word_does_not_exist'], [], id='word does not exist')
    ]
)
def test_query_inverted_index_intersect_results(tiny_dataset_fio, query, expected_answer):
    """Tests query"""
    loaded_documents = load_documents(tiny_dataset_fio)
    tiny_inverted_index = build_inverted_index(loaded_documents)
    answer = tiny_inverted_index.query(query)
    assert sorted(answer) == sorted(expected_answer), (
        f'Expected answer is {expected_answer}, but you got {answer}'
    )


def test_can_load_wikipedia_sample():
    """Tests loading of a big dataset"""
    loaded_documents = load_documents(DATASET_BIG_PATH)
    assert len(loaded_documents) == 32, (
        'you incorrectly loaded Wikipedia sample'
    )


@pytest.fixture()
def wikipedia_documents():
    """Creates documents dictionary for a big dataset"""
    documents = load_documents(DATASET_BIG_PATH)
    return documents


def test_can_build_and_query_inverted_index(wikipedia_documents):
    """Test build and query for a big dataset"""
    wikipedia_inverted_index = build_inverted_index(wikipedia_documents)
    doc_ids = wikipedia_inverted_index.query(['apollo'])
    assert isinstance(doc_ids, list), (
        'inverted index query should return list'
    )


def test_can_dump_and_load_inverted_index_v1(tmpdir, tiny_dataset_fio):
    """Test dump and load for a tiny dataset"""
    index_fio = tmpdir.join('index_dump.json')
    loaded_documents = load_documents(tiny_dataset_fio)
    tiny_inverted_index = build_inverted_index(loaded_documents)
    tiny_inverted_index.dump(index_fio)
    loaded_inverted_index = InvertedIndex.load(index_fio)
    assert tiny_inverted_index == loaded_inverted_index, (
        'load should return the same inverted index'
    )


@pytest.fixture()
def wikipedia_inverted_index(wikipedia_documents):
    """Builds inverted index for a big dataset"""
    wikipedia_inverted_index = build_inverted_index(wikipedia_documents)
    return wikipedia_inverted_index


def test_can_dump_and_load_inverted_index_v2(tmpdir, wikipedia_inverted_index):
    """Test dump and load for a big dataset"""
    index_fio = tmpdir.join('index_dump.json')
    wikipedia_inverted_index.dump(index_fio)
    loaded_inverted_index = InvertedIndex.load(index_fio)
    assert wikipedia_inverted_index == loaded_inverted_index, (
        'load should return the same inverted index'
    )
