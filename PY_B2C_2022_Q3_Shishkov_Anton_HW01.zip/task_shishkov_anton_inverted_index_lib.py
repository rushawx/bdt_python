"""inverted index module"""
from __future__ import annotations
import re
import json
from collections import Counter

from typing import Dict, List


class InvertedIndex:
    """inverted index class"""
    def __init__(self, inverted_index_dict):
        """Initialize Inverted Index object"""
        self.inverted_index_dict = inverted_index_dict

    def query(self, words: List[str]) -> List[int]:
        """Returns document ids for given words"""
        check_list = {word.lower(): False for word in words}
        ids_list = []
        for word in words:
            word_ids = self.inverted_index_dict.get(word.lower(), [])
            if word_ids:
                check_list[word.lower()] = True
            ids_list.extend(word_ids)
        ids_counter = Counter(ids_list)
        ids_list = [x for x in ids_counter if ids_counter.get(x) == len(words)]
        if all(check_list.values()):
            ids_list = list(set(ids_list))
        else:
            ids_list = []
        return ids_list

    def dump(self, filepath: str) -> None:
        """Dumps Inverted Index object to JSON"""
        with open(filepath, 'w') as file_path:
            json.dump(self.inverted_index_dict, fp=file_path)

    @classmethod
    def load(cls, filepath: str) -> InvertedIndex:
        """Loads Inverted Index object from JSON"""
        with open(filepath, 'r') as file_path:
            obj = json.load(fp=file_path)
        return obj

    def __eq__(self, rhs):
        """Overrides Inverted Index object comparison"""
        return self.inverted_index_dict == rhs


def load_documents(filepath: str) -> Dict[int, str]:
    """Creates a dictionary of ids and contents from a given string"""
    doc_dict = dict()
    with open(filepath, encoding='utf8') as file_path:
        for line in file_path.readlines():
            doc_id, content = line.lower().split('\t', 1)
            doc_id = int(doc_id)
            doc_dict[doc_id] = content.strip()
    return doc_dict


def build_inverted_index(documents: Dict[int, str]) -> InvertedIndex:
    """Builds Inverted Index object from a given dictionary"""
    inv_ind_dict = dict()
    for doc_id, content in documents.items():
        words = re.split(r'\W+', content)
        for word in words:
            ids_list = inv_ind_dict.get(word, [])
            if doc_id not in ids_list:
                ids_list.append(doc_id)
            inv_ind_dict[word] = ids_list
    return InvertedIndex(inverted_index_dict=inv_ind_dict)
