# !/usr/bin/env python3
"""inverted index module"""
from __future__ import annotations
import sys
import re
import json
import pickle
from argparse import ArgumentParser, ArgumentDefaultsHelpFormatter
from collections import Counter
from typing import Dict, List


DEFAULT_DATASET_PATH = 'tiny_wikipedia_sample.txt'
DEFAULT_INVERTED_INDEX_PATH = 'inverted.index'
DEFAULT_STORAGE_STRATEGY = 'json'


class InvertedIndex:
    """inverted index class"""
    def __init__(self, inverted_index_dict):
        """Initialize Inverted Index object"""
        self.inverted_index_dict = inverted_index_dict

    def query(self, words: List[str]) -> List[int]:
        """Returns document ids for given words"""
        assert isinstance(words, list), (
            'query should be provided as a list of words, but user provided: '
            f'{repr(words)}'
        )
        print(f'query inverted index with request {words}', file=sys.stderr)
        check_list = {word.lower(): False for word in words}
        ids_list = []
        for word in words:
            word_ids = self.inverted_index_dict.get(word.lower(), [])
            if word_ids:
                check_list[word.lower()] = True
            ids_list.extend(word_ids)
        ids_counter = Counter(ids_list)
        ids_list = [x for x in ids_counter if ids_counter.get(x) == len(words)]
        if all(check_list.values()):
            ids_list = list(set(ids_list))
        else:
            ids_list = []
        return ids_list

    def dump(self, filepath: str, storage_method: str) -> None:
        """Dumps Inverted Index object to JSON"""
        if storage_method == 'json':
            with open(filepath, 'w') as file_path:
                json.dump(self.inverted_index_dict, fp=file_path)
        elif storage_method == 'pickle':
            with open(filepath, 'wb') as file_path:
                pickle.dump(self.inverted_index_dict, file=file_path)

    @classmethod
    def load(cls, filepath: str) -> InvertedIndex:
        """Loads Inverted Index object from JSON"""
        with open(filepath, 'r') as file_path:
            obj = json.load(fp=file_path)
        return InvertedIndex(inverted_index_dict=obj)

    def __eq__(self, rhs):
        """Overrides Inverted Index object comparison"""
        return self.inverted_index_dict == rhs


def load_documents(filepath: str) -> Dict[int, str]:
    """Creates a dictionary of ids and contents from a given string"""
    doc_dict = dict()
    with open(filepath, encoding='utf8') as file_path:
        for line in file_path.readlines():
            doc_id, content = line.lower().split('\t', 1)
            doc_id = int(doc_id)
            doc_dict[doc_id] = content.strip()
    return doc_dict


def build_inverted_index(documents: Dict[int, str]) -> InvertedIndex:
    """Builds Inverted Index object from a given dictionary"""
    inv_ind_dict = dict()
    for doc_id, content in documents.items():
        words = re.split(r'\W+', content)
        for word in words:
            ids_list = inv_ind_dict.get(word, [])
            if doc_id not in ids_list:
                ids_list.append(doc_id)
            inv_ind_dict[word] = ids_list
    return InvertedIndex(inverted_index_dict=inv_ind_dict)


def setup_parser(parser):
    """setups arguments parser for Inverted Index CLI"""
    subparser = parser.add_subparsers(help='choose command')

    build_parser = subparser.add_parser(
        'build', help='build inverted index and save into hard drive',
        formatter_class=ArgumentDefaultsHelpFormatter,
    )
    build_parser.add_argument(
        '-s', '--strategy', dest='storage_strategy',
        required=False,
        metavar='STORAGE_STRATEGY',
        help='choose a method to store inverted index to file system',
        default=DEFAULT_STORAGE_STRATEGY,
        choices=['json', 'pickle'],
    )
    build_parser.add_argument(
        '-d', '--dataset', dest='dataset_path',
        required=False,
        metavar='DATASET_PATH',
        help='path to load dataset, default dataset path is %(default)s',
        default=DEFAULT_DATASET_PATH,
    )
    build_parser.add_argument(
        '-o', '--output', dest='output_path',
        required=False,
        metavar='OUTPUT_PATH',
        help='path to dump inverted index, default output path is %(default)s',
        default=DEFAULT_INVERTED_INDEX_PATH,
    )
    build_parser.set_defaults(callback=build_callback)

    query_parser = subparser.add_parser(
        'query', help='query against inverted index',
        formatter_class=ArgumentDefaultsHelpFormatter,
    )
    query_parser.add_argument(
        '-ji', '--json-index', dest='input_path',
        help='path to stored inverted index',
        default=DEFAULT_INVERTED_INDEX_PATH,
    )
    query_parser.add_argument(
        '-q', '--query', dest='query_str', nargs='+',
        action='append',
        required=False,
        metavar='QUERY',
        help='query to search words through inverted index of documents'
    )
    query_parser.set_defaults(callback=query_callback)


def build_callback(arguments):
    """callback for build command"""
    documents = load_documents(arguments.dataset_path)
    inverted_index = build_inverted_index(documents=documents)
    inverted_index.dump(arguments.output_path, arguments.storage_strategy)


def query_callback(arguments):
    """callback for query command"""
    inverted_index = InvertedIndex.load(arguments.input_path)
    for single_query in arguments.query_str:
        document_ids = inverted_index.query(single_query)
        print(','.join(map(str, document_ids)))


def main():
    """parses args, then loads documents, builds index and makes queries"""
    parser = ArgumentParser(
        prog='inverted_index_cli',
        description='Inverted Index CLI',
        formatter_class=ArgumentDefaultsHelpFormatter
    )
    setup_parser(parser)
    arguments = parser.parse_args()
    print(arguments, file=sys.stderr)
    arguments.callback(arguments)


main()
